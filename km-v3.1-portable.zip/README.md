# Academic Knowledge Manager — Portable Bootstrap (v3.1)

This is a fresh, portable copy of the Academic Knowledge Management System.
Copy this folder to any new location and it becomes a functional knowledge base.

## Quick Start
1. Copy this folder to your desired location
2. Point the Cowork workspace to this folder
3. The skill auto-activates

## Structure
- `tools/` — Governance files (CONSTITUTION, WORKFLOW, STRATEGY) + indices
- `work/` — Draft staging area
- `knowledge/` — Published knowledge library
- `baseline/` — Constitution version archive
- `conversations/` — Session wiki (grows with use)
- `memory/` — Persistent memory

## Key Files
| File | Role |
|------|------|
| tools/CONSTITUTION.md | Immutable governance rules (v3.1) |
| tools/WORKFLOW.md | Fixed operational procedures W1–W8 |
| tools/STRATEGY.md | Heuristics with activation/expiry S1–S11 |
| tools/activity.log | Global chronological operation log |
| tools/CACHE.md | State cache (auto-updated) |

## Scheduled Tasks
Create these via Cowork scheduled tasks:
- `daily-knowledge-review` — cron: 0 3 * * *
- `weekly-knowledge-analysis` — cron: 0 10 * * 6

## Baseline
- `baseline/CONSTITUTION-v3.1.md` — current baseline snapshot

Created: 2026-05-30. Constitution v3.1. Art. I–XII.
