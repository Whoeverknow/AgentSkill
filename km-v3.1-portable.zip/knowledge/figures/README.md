# Figures Registry
> Governing policy: See [CONSTITUTION.md](../../tools/CONSTITUTION.md) Article V

## Figure Classification
| Class | Criteria | Action |
|-------|----------|--------|
| A — Stable | DOI/ISBN/arXiv | Record source + figure number only |
| B — Ephemeral | Web/screenshot/rare book | Create entry in figures/ dir |

Each Class B figure MUST have `#figure` + content tag.
