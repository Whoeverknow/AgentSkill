# Academic Knowledge Base · Master Index

> All operations governed by [CONSTITUTION.md](./CONSTITUTION.md) v3.1
> Indexes only **knowledge/** (published entries).

---

## Quick Stats
- **Total entries**: 0
- **Last updated**: {init_date}

---

## By Priority
### P0 (Core) — *No entries*
### P1 (Important) — *No entries*
### P2 (Reference) — *No entries*
### P3 (Archived) — *No entries*

## By Theme — *No themes*

## By Tag — *No tags*
