# Tag Graph
> Per [CONSTITUTION.md](./CONSTITUTION.md) Article VI

## Tag Categories
| Category | Convention | Examples |
|----------|-----------|----------|
| Content | lowercase, hyphenated | `#python`, `#natural-capital` |
| Status | `st-` prefixed | `#st-new`, `#st-mastered`, `#st-unverified`, `#st-archived`, `#st-stale` |
| Type | `t-` prefixed | `#t-concept`, `#t-method`, `#t-tool`, `#t-case`, `#t-data`, `#t-finding` |

*No tags registered*
