# Knowledge Graph
> Mermaid concept-relationship graph — per [CONSTITUTION.md](./CONSTITUTION.md)

```mermaid
graph LR
  subgraph Legend
    A[Awaiting first knowledge entry]
  end
```
